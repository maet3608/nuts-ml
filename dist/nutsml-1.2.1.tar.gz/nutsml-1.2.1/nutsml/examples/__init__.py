"""
Example nuts-ml pipelines
"""