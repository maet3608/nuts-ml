"""
.. module:: test_viewer
   :synopsis: Unit tests for viewer module
"""
