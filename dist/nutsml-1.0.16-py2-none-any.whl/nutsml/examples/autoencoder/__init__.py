"""
Example autoencoders using nuts.
"""