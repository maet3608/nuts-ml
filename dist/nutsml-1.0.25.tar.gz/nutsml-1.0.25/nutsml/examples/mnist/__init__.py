"""
Example nuts-ml pipelines for MNIST
"""