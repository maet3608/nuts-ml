"""
Example nuts-ml pipelines
"""