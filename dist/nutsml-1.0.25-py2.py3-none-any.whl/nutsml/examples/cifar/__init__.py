"""
Example nuts-ml pipelines for CIFAR-10
"""