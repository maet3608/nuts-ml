"""
Example autoencoders using nuts.
"""