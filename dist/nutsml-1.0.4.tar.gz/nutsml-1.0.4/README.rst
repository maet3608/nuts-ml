nuts-ml
=======

Flow-based data pre-processing for (GPU/deep) machine learning.

Installation guide, API documentation and tutorials can be found
`here <https://maet3608.github.io/nuts-ml/>`_

